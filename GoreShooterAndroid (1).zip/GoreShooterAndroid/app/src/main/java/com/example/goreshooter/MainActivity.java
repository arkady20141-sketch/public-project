package com.example.goreshooter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(new GameView(this));
    }

    @Override
    public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }
}

class GameView extends SurfaceView implements SurfaceHolder.Callback, Runnable {
    static final int W = 480, H = 300, MAXP = 3500, MAXE = 40;
    // ---------- maps: '#' wall, '2'/'3' coloured walls, 'o' = pit you can fall into ----------
    static final String[] MAP_NAMES = {"PIT ARENA", "BRIDGES", "RUINS"};
    static final String[][] MAPS = {
        {   "################",
            "#..............#",
            "#..............#",
            "#..22......22..#",
            "#..2........2..#",
            "#......33......#",
            "#......33....oo#",
            "#............oo#",
            "#.....oooo...oo#",
            "#..2..oooo...2.#",
            "#..22......22..#",
            "#..............#",
            "#.oo...........#",
            "#.oo...........#",
            "#..............#",
            "################" },
        {   "################",
            "#..............#",
            "#..............#",
            "#..22......22..#",
            "#..............#",
            "#..............#",
            "#oooo..oo..oooo#",
            "#oooo..oo..oooo#",
            "#..............#",
            "#..............#",
            "#..22......22..#",
            "#..............#",
            "#..............#",
            "#..............#",
            "#..............#",
            "################" },
        {   "################",
            "#..............#",
            "#.oo.......oo..#",
            "#.oo..33...oo..#",
            "#.....33.......#",
            "#..............#",
            "#...oo....oo...#",
            "#...oo....oo...#",
            "#..............#",
            "#.......33.....#",
            "#..oo...33.oo..#",
            "#..oo.......oo.#",
            "#..............#",
            "#..22......22..#",
            "#..............#",
            "################" }
    };
    final int[][] MAP = new int[16][16];
    final boolean[][] PIT = new boolean[16][16];
    int mapIdx, banner;

    void loadMap(int idx) {
        mapIdx = idx % MAPS.length;
        for (int y = 0; y < 16; y++)
            for (int x = 0; x < 16; x++) {
                char c = MAPS[mapIdx][y].charAt(x);
                MAP[y][x] = c == '#' ? 1 : c == '2' ? 2 : c == '3' ? 3 : 0;
                PIT[y][x] = c == 'o';
            }
        pN = 0; pHead = 0; banner = 120;        // blood belongs to the old map
    }

    // ---------- weapons (all game stats) ----------
    static final String[] WN = {"KNIFE", "PISTOL", "REVOLVER", "SMG", "SHOTGUN",
                                "ASSAULT RIFLE", "LMG", "SNIPER", "GRENADE LAUNCHER", "MINIGUN"};
    static final int[]    WDMG   = {50, 25, 70, 14, 12, 22, 20, 150, 140, 9};      // per bullet/pellet
    static final int[]    WCD    = {20, 14, 32, 4, 45, 6, 5, 70, 60, 2};          // frames between shots
    static final int[]    WPEL   = {1, 1, 1, 1, 9, 1, 1, 1, 1, 1};                // pellets per shot
    static final double[] WSPR   = {0, 0.02, 0.01, 0.07, 0.12, 0.03, 0.05, 0, 0, 0.08}; // spread (rad)
    static final double[] WRNG   = {1.3, 14, 16, 12, 8, 18, 18, 30, 25, 18};      // range
    static final int[]    WMAG   = {0, 12, 6, 30, 8, 30, 80, 5, 4, 150};          // magazine (0 = none)
    static final int[]    WREL   = {0, 60, 90, 70, 100, 80, 160, 100, 110, 150};  // reload frames
    static final double[] WNOISE = {3, 10, 14, 12, 15, 14, 15, 20, 18, 16};       // how far enemies hear it
    static final int[]    GW     = {10, 22, 24, 26, 34, 28, 40, 28, 44, 50};      // gun sprite size
    static final int[]    GH     = {50, 60, 66, 70, 70, 76, 80, 76, 80, 90};
    static final int[]    GL     = {0, 18, 24, 22, 30, 34, 40, 50, 26, 44};

    // ballistics: drag per unit (energy lost with distance), muzzle speed (units/s), recoil kick (px)
    static final double[] WK   = {0, 0.040, 0.030, 0.040, 0.070, 0.012, 0.012, 0.006, 0, 0.012};
    static final double[] WV   = {0, 175, 200, 190, 200, 450, 425, 425, 40, 425};
    static final double[] WREC = {0, 6, 14, 3, 18, 4, 4, 12, 20, 2};
    static final double G = 4.9;   // gravity in units/s^2 (1 unit ~ 2 m)

    static final int CEIL = rgb(30, 30, 40), SKIN = rgb(200, 170, 140);
    static final int PITC = rgb(6, 5, 9), LIP = rgb(105, 95, 85);

    static int rgb(int r, int g, int b) { return 0xFF000000 | (r & 255) << 16 | (g & 255) << 8 | (b & 255); }

    // state: 0 idle, 1 investigate noise, 2 chase, 3 search around last known spot
    static class Enemy {
        double x, y, hp = 100, tx, ty, lx, ly, wx, wy;
        double head = 30, armL = 40, armR = 40, legL = 50, legR = 50, blood = 100, bleed;
        boolean dead, gibbed, los, headGone, armLGone, armRGone, legLGone, legRGone;
        int state, timer, probes, wt, id, stun, stumps;
    }

    // ---------- preallocated buffers (no allocation inside the game loop) ----------
    final Bitmap bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
    final Canvas bc = new Canvas(bmp);
    final Paint p = new Paint();
    final Rect dst = new Rect();
    final int[] pix = new int[W * H];
    final double[] zb = new double[W];
    final ArrayList<Enemy> enemies = new ArrayList<>();
    final Random rnd = new Random();

    // particle pool (ring buffer)
    final double[] PX = new double[MAXP], PY = new double[MAXP], PZ = new double[MAXP];
    final double[] VX = new double[MAXP], VY = new double[MAXP], VZ = new double[MAXP], PS = new double[MAXP];
    final int[] PC = new int[MAXP];
    final byte[] PF = new byte[MAXP];           // 1 = resting, 2 = gib
    int pHead, pN;

    // enemy draw order + "!" markers
    final int[] eo = new int[MAXE];
    final double[] ed = new double[MAXE];
    final float[] mkx = new float[MAXE], mky = new float[MAXE];
    final int[] mks = new int[MAXE];
    int mkn;

    // path finding buffers
    final int[] bdist = new int[256], bq = new int[256];
    double nsx, nsy;

    // ---------- game state ----------
    volatile double pa;
    double px, py;
    int hp, kills, wave, cooldown, flash, hurt, stepTick, frameNo, weapon, reloadTimer;
    final int[] ammo = new int[WN.length];
    volatile boolean firing, needReset = true, swapReq, reloadReq, kickReq, grabReq;
    volatile float mvx, mvy;
    volatile double shear;            // vertical look (px), + = up
    double kick, bleedP, bleedAcc;    // recoil, player bleeding
    int legInj, armInj, hitTimer;
    String hitTxt = "";
    // melee: grab + kick (player <-> enemy)
    int kickCd, kickAnim, holdTimer, grabTimer, grabHits;
    // pits: 0 none, 1 falling, 2 hanging on the edge, 3 climbing out
    int fallState, fallT, hangT, climbT, fallCd;
    double ledgeX, ledgeY;
    Enemy heldEnemy, grabber;          // heldEnemy = I hold it, grabber = it holds me

    int movePid = -1, lookPid = -1, firePid = -1;
    float moveX0, moveY0, lastLookX, lastLookY;

    Thread th;
    volatile boolean running;

    public GameView(Context ctx) {
        super(ctx);
        getHolder().addCallback(this);
        setFocusable(true);
    }

    @Override public void surfaceCreated(SurfaceHolder h) {
        running = true;
        th = new Thread(this);
        th.start();
    }
    @Override public void surfaceChanged(SurfaceHolder h, int f, int w, int hh) { }
    @Override public void surfaceDestroyed(SurfaceHolder h) {
        running = false;
        try { th.join(); } catch (InterruptedException e) { }
    }

    // ---------- touch input ----------
    float fireX() { return getWidth() - 150; }
    float fireY() { return getHeight() - 150; }
    float swapX() { return getWidth() - 390; }
    float swapY() { return getHeight() - 110; }
    float relX() { return getWidth() - 150; }
    float relY() { return getHeight() - 380; }
    float kickX() { return getWidth() - 330; }
    float kickY() { return getHeight() - 260; }
    float grabX() { return getWidth() - 500; }
    float grabY() { return getHeight() - 250; }
    boolean in(float x, float y, float cx, float cy, float r) { return Math.hypot(x - cx, y - cy) < r; }
    float cl(float v) {
        if (Math.abs(v) < 0.15f) return 0;
        return Math.max(-1f, Math.min(1f, v));
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int act = e.getActionMasked(), idx = e.getActionIndex();
        switch (act) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int id = e.getPointerId(idx);
                float x = e.getX(idx), y = e.getY(idx);
                if (hp <= 0) { needReset = true; break; }
                if (in(x, y, fireX(), fireY(), 110)) { if (firePid < 0) { firePid = id; firing = true; } }
                else if (in(x, y, swapX(), swapY(), 80)) swapReq = true;
                else if (in(x, y, relX(), relY(), 80)) reloadReq = true;
                else if (in(x, y, kickX(), kickY(), 80)) kickReq = true;
                else if (in(x, y, grabX(), grabY(), 80)) grabReq = true;
                else if (x < getWidth() / 2f) {
                    if (movePid < 0) { movePid = id; moveX0 = x; moveY0 = y; mvx = 0; mvy = 0; }
                } else if (lookPid < 0) { lookPid = id; lastLookX = x; lastLookY = y; }
                break;
            }
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) {
                    int id = e.getPointerId(i);
                    float x = e.getX(i), y = e.getY(i);
                    if (id == movePid) { mvx = cl((x - moveX0) / 120f); mvy = cl((y - moveY0) / 120f); }
                    else if (id == lookPid) {
                        pa += (x - lastLookX) * 0.006; lastLookX = x;
                        if (getHeight() > 0) shear = Math.max(-100, Math.min(100, shear - (y - lastLookY) * H / (double) getHeight() * 1.2));
                        lastLookY = y;
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP: {
                int id = e.getPointerId(idx);
                if (id == movePid) { movePid = -1; mvx = 0; mvy = 0; }
                if (id == lookPid) lookPid = -1;
                if (id == firePid) { firePid = -1; firing = false; }
                break;
            }
            case MotionEvent.ACTION_CANCEL:
                movePid = lookPid = firePid = -1; mvx = 0; mvy = 0; firing = false;
                break;
        }
        return true;
    }

    // ---------- main loop ----------
    @Override public void run() {
        while (running) {
            long t0 = System.currentTimeMillis();
            if (needReset) reset();
            update();
            Canvas c = getHolder().lockCanvas();
            if (c != null) {
                try {
                    render();
                    dst.set(0, 0, c.getWidth(), c.getHeight());
                    c.drawBitmap(bmp, null, dst, null);
                    hud(c);
                } finally { getHolder().unlockCanvasAndPost(c); }
            }
            long dt = System.currentTimeMillis() - t0;
            if (dt < 16) try { Thread.sleep(16 - dt); } catch (InterruptedException e) { }
        }
    }

    void reset() {
        loadMap(0); px = 1.5; py = 1.5; pa = 0.6; hp = 100; kills = 0; wave = 0; fallState = 0; fallCd = 0;
        weapon = 1; reloadTimer = 0; cooldown = 0;
        shear = 0; kick = 0; bleedP = 0; bleedAcc = 0; legInj = 0; armInj = 0; hitTimer = 0;
        heldEnemy = null; grabber = null; kickCd = 0; kickAnim = 0; holdTimer = 0; grabTimer = 0; grabHits = 0;
        System.arraycopy(WMAG, 0, ammo, 0, WN.length);
        pN = 0; pHead = 0;
        spawnWave();
        needReset = false;
    }

    void spawnWave() {
        enemies.clear();
        heldEnemy = null; grabber = null;
        wave++;
        if (wave > 1 && (wave - 1) % 2 == 0) { loadMap(mapIdx + 1); px = 1.5; py = 1.5; fallState = 0; }   // new map every 2 waves
        int n = Math.min(2 + wave, MAXE - 1);
        for (int i = 0; i < n; i++) {
            Enemy e = new Enemy();
            e.id = i;
            do { e.x = 1.5 + rnd.nextInt(14); e.y = 1.5 + rnd.nextInt(14); }
            while (MAP[(int) e.y][(int) e.x] != 0 || PIT[(int) e.y][(int) e.x] || Math.hypot(e.x - px, e.y - py) < 6);
            enemies.add(e);
        }
    }

    void update() {
        frameNo++;
        if (hitTimer > 0) hitTimer--;
        if (banner > 0) banner--;
        if (hp <= 0) { updateParts(); return; }
        double dx = Math.cos(pa), dy = Math.sin(pa), sp = legInj > 0 ? 0.03 : 0.05;
        if (grabber != null) sp = 0; else if (heldEnemy != null) sp *= 0.5;
        if (fallState != 0) sp = 0;
        if (fallCd > 0) { fallCd--; sp = 0; }
        double fwd = -mvy, str = mvx;
        double mx = dx * fwd - dy * str, my = dy * fwd + dx * str;
        double nx = px + mx * sp, ny = py + my * sp;
        double ox = px, oy = py;
        if (MAP[(int) py][(int) nx] == 0) px = nx;
        if (MAP[(int) ny][(int) px] == 0) py = ny;
        if (fallState == 0 && PIT[(int) py][(int) px]) startFall(ox, oy);     // stepped into a hole

        if (swapReq) { swapReq = false; weapon = (weapon + 1) % WN.length; cooldown = 12; reloadTimer = 0; }
        if (reloadReq) { reloadReq = false; startReload(); }
        if (cooldown > 0) cooldown--;
        if (flash > 0) flash--;
        if (hurt > 0) hurt--;
        if (reloadTimer > 0) {
            if (--reloadTimer == 0) ammo[weapon] = WMAG[weapon];
        } else if (firing && cooldown == 0 && fallState == 0) {
            if (WMAG[weapon] > 0 && ammo[weapon] <= 0) startReload();
            else {
                fire(weapon);
                if (WMAG[weapon] > 0) ammo[weapon]--;
                cooldown = WCD[weapon]; flash = 4;
            }
        }

        // player wounds: recoil recovery, bleeding, shaky arm, limp
        kick *= 0.9;
        if (bleedP > 0.0005) {
            bleedAcc += bleedP;
            if (bleedAcc >= 1) { hp--; bleedAcc -= 1; }
            bleedP *= 0.997;                       // slowly clots
        }
        if (armInj > 0) { armInj--; pa += (rnd.nextDouble() - 0.5) * 0.012; kick += (rnd.nextDouble() - 0.5) * 1.5; }
        if (legInj > 0) legInj--;
        fallUpdate();
        meleeUpdate();

        if (Math.abs(mvx) + Math.abs(mvy) > 0.3 && ++stepTick % 20 == 0) noise(px, py, 3.5);

        boolean alive = false;
        for (int i = 0; i < enemies.size(); i++) {
            Enemy e = enemies.get(i);
            if (e.dead) continue;
            alive = true;
            if (PIT[(int) e.y][(int) e.x] && heldEnemy != e) {          // enemy fell into a pit
                kill(e, false); e.gibbed = true; hitTxt = "PIT KILL"; hitTimer = 40; continue;
            }
            double tb = e.bleed + e.stumps * 0.03;      // blood loss per frame
            if (tb > 0) {
                e.blood -= tb; e.bleed *= 0.998;
                if (tb > 0.01 && (frameNo + e.id) % 4 == 0) drip(e);
                if (e.blood <= 0) { kill(e, false); continue; }
            }
            double d = Math.hypot(px - e.x, py - e.y);
            if ((frameNo + e.id) % 3 == 0) e.los = hasLOS(e.x, e.y, px, py);
            boolean los = e.los;
            if ((los && d < 9) || d < 1.0) wake(e);
            double gd = Math.hypot(e.tx - e.x, e.ty - e.y);
            if (grabber == e || heldEnemy == e) continue;      // locked in a grapple
            if (e.stun > 0) e.stun--;
            else {
                switch (e.state) {
                    case 2:
                        if (d > 0.8) moveTo(e, e.tx, e.ty, 0.026);
                        if (!los && gd < 0.4) startSearch(e);
                        break;
                    case 1:
                        moveTo(e, e.tx, e.ty, 0.02);
                        if (gd < 0.4) startSearch(e);
                        break;
                    case 3:
                        moveTo(e, e.tx, e.ty, 0.015);
                        if (gd < 0.35) { if (--e.probes <= 0) e.state = 0; else pickProbe(e); }
                        break;
                    default:
                        if (--e.timer <= 0 || gd < 0.3) {
                            e.tx = e.x + rnd.nextDouble() * 6 - 3; e.ty = e.y + rnd.nextDouble() * 6 - 3;
                            int cx = (int) e.tx, cy = (int) e.ty;
                            if (cx < 1 || cy < 1 || cx > 14 || cy > 14 || MAP[cy][cx] != 0 || PIT[cy][cx]) { e.tx = e.x; e.ty = e.y; }
                            e.timer = 90 + rnd.nextInt(120);
                        }
                        moveTo(e, e.tx, e.ty, 0.008);
                }
                if (d < 0.8 && los) {
                    if (grabber == null && fallState == 0 && !(e.armLGone && e.armRGone) && rnd.nextInt(80) == 0) {
                        if (heldEnemy != null) heldEnemy = null;     // tackled, let go
                        grabber = e; grabTimer = 0; grabHits = 0;
                    } else if (rnd.nextInt(30) == 0) hurtPlayer(e);
                }
            }
        }
        if (!alive) spawnWave();
        updateParts();
    }

    // ---------- pits: fall, grab the ledge, climb out ----------
    boolean pathClear(double x0, double y0, double x1, double y1) {   // like hasLOS but also blocked by pits
        double d = Math.hypot(x1 - x0, y1 - y0);
        int n = (int) (d / 0.1) + 1;
        for (int i = 1; i < n; i++) {
            double t = (double) i / n;
            int cx = (int) (x0 + (x1 - x0) * t), cy = (int) (y0 + (y1 - y0) * t);
            if (MAP[cy][cx] != 0 || PIT[cy][cx]) return false;
        }
        return true;
    }

    void startFall(double ox, double oy) {
        px = ox; py = oy; ledgeX = ox; ledgeY = oy;       // the ledge is the last solid spot
        fallState = 1; fallT = 0; hangT = 0; climbT = 0;
        heldEnemy = null; grabber = null;
        hitTxt = "FALLING!"; hitTimer = 30;
    }

    void landInPit() {                                     // missed the ledge: hit the bottom, crawl back out hurt
        hp -= 50; hurt = 20; legInj = 900; bleedP += 0.004;
        fallState = 0; fallCd = 25; px = ledgeX; py = ledgeY;
        hitTxt = "HIT THE BOTTOM"; hitTimer = 50;
    }

    void fallUpdate() {
        if (fallState == 0) return;
        boolean g = grabReq;
        grabReq = false; kickReq = false;
        if (fallState == 1) {
            fallT++;
            kick += (rnd.nextDouble() - 0.5) * 3;          // shake
            if (g && fallT <= 26) { fallState = 2; hangT = 0; hitTxt = "GOT THE LEDGE!"; hitTimer = 40; }
            else if (fallT >= 40) landInPit();
            return;
        }
        hangT++;
        if (fallState == 2) { if (g) { fallState = 3; climbT = 0; } }
        else if (++climbT >= 45) { fallState = 0; fallCd = 25; hitTxt = "CLIMBED OUT"; hitTimer = 40; return; }
        if (hangT > 220) { landInPit(); return; }          // grip gives out
        for (int i = 0; i < enemies.size(); i++) {         // enemies stomp on your fingers
            Enemy e = enemies.get(i);
            if (e.dead || e.stun > 0 || Math.hypot(e.x - px, e.y - py) > 1.1) continue;
            if (rnd.nextInt(45) == 0) { landInPit(); hitTxt = "KICKED OFF!"; return; }
        }
    }

    // ---------- melee: grab and kick ----------
    Enemy nearestFront(double range) {
        double dx = Math.cos(pa), dy = Math.sin(pa), bt = 1e9;
        Enemy best = null;
        for (int i = 0; i < enemies.size(); i++) {
            Enemy e = enemies.get(i);
            if (e.dead) continue;
            double ex = e.x - px, ey = e.y - py, along = ex * dx + ey * dy;
            if (along < 0.1 || along > range || along >= bt) continue;
            if (Math.abs(-ex * dy + ey * dx) > 0.45 || !hasLOS(px, py, e.x, e.y)) continue;
            best = e; bt = along;
        }
        return best;
    }

    void shove(Enemy e, double dist) {                  // push away from the player; slam into a wall on a long throw
        double ax = e.x - px, ay = e.y - py, d = Math.hypot(ax, ay);
        if (d < 1e-6) { ax = Math.cos(pa); ay = Math.sin(pa); d = 1; }
        ax /= d; ay /= d;
        for (double moved = 0; moved < dist; moved += 0.1) {
            double nx = e.x + ax * 0.1, ny = e.y + ay * 0.1;
            if (MAP[(int) ny][(int) nx] != 0) { if (dist >= 2) applyZone(e, 25, 1); break; }
            e.x = nx; e.y = ny;
        }
    }

    void kickHit(Enemy e, double D, boolean knock) {
        double r = rnd.nextDouble();
        int zn = r < 0.05 ? 0 : r < 0.6 ? 1 : rnd.nextBoolean() ? (e.legLGone ? 1 : 4) : (e.legRGone ? 1 : 5);
        applyZone(e, D, zn);
        if (!e.dead) { e.stun = Math.max(e.stun, 25); if (knock) shove(e, 0.6); }
    }

    void meleeUpdate() {
        if (kickCd > 0) kickCd--;
        if (kickAnim > 0) kickAnim--;
        boolean kReq = kickReq, gReq = grabReq;
        kickReq = false; grabReq = false;
        if (grabber != null && (grabber.dead || grabber.stun > 0)) grabber = null;   // shot or hurt: it lets go

        if (grabber != null) {                           // an enemy is holding me: knees and punches
            Enemy g = grabber;
            grabTimer++;
            if (grabTimer % 25 == 0) { hp -= 6; hurt = 8; bleedP += 0.004; hitTxt = "GRABBED"; hitTimer = 20; }
            if (kReq && kickCd == 0) {                   // mash KICK to break free
                kickCd = 20; kickAnim = 10; grabHits++; noise(px, py, 6);
                applyZone(g, 12, rnd.nextBoolean() ? 1 : 4 + rnd.nextInt(2));
                g.stun = 0;
                if (g.dead) grabber = null;
                else if (grabHits >= 4) { grabber = null; shove(g, 0.8); g.stun = 30; }
            }
            if (grabber != null && grabTimer > 180) {    // it throws me down
                hp -= 10; hurt = 10; grabber.stun = 20; grabber = null;
            }
            return;
        }
        if (heldEnemy != null) {                         // I am holding an enemy
            Enemy e = heldEnemy;
            if (e.dead) { heldEnemy = null; return; }
            double hx = px + Math.cos(pa) * 0.7, hy = py + Math.sin(pa) * 0.7;
            if (MAP[(int) hy][(int) hx] == 0) { e.x = hx; e.y = hy; }
            e.stun = Math.max(e.stun, 2);
            if (--holdTimer <= 0) { heldEnemy = null; e.stun = 0; return; }   // it breaks free
            if (holdTimer % 40 == 0) hurtPlayer(e);                           // it fights back
            if (kReq && kickCd == 0) { kickCd = 20; kickAnim = 10; noise(px, py, 6); kickHit(e, 38, false); }
            else if (gReq) { heldEnemy = null; shove(e, 3.0); e.stun = Math.max(e.stun, 60); }   // throw
            return;
        }
        if (kReq && kickCd == 0) {
            kickCd = 25; kickAnim = 10; noise(px, py, 6);
            Enemy t = nearestFront(1.2);
            if (t != null) kickHit(t, 22, true);
        }
        if (gReq) {
            Enemy t = nearestFront(1.1);
            if (t != null) { heldEnemy = t; holdTimer = 150; wake(t); }
        }
    }

    void hurtPlayer(Enemy e) {
        double mul = Math.max(0.2, 1 - 0.4 * ((e.armLGone ? 1 : 0) + (e.armRGone ? 1 : 0)));
        double dmg = 8 * mul, r = rnd.nextDouble();
        if (r < 0.5) { hp -= (int) Math.ceil(dmg); bleedP += dmg * 0.0015; }
        else if (r < 0.75) { hp -= (int) Math.ceil(dmg * 0.6); armInj = 600; bleedP += dmg * 0.0015; }
        else { hp -= (int) Math.ceil(dmg * 0.7); legInj = 600; bleedP += dmg * 0.0015; }
        hurt = 8;
    }

    void drip(Enemy e) {
        addPart(e.x, e.y, 0.35, (rnd.nextDouble() - 0.5) * 0.01, (rnd.nextDouble() - 0.5) * 0.01, 0.01,
                0.012 + rnd.nextDouble() * 0.01, rgb(120 + rnd.nextInt(80), rnd.nextInt(15), rnd.nextInt(15)));
    }

    // ---------- weapons ----------
    void startReload() {
        int w = weapon;
        if (WMAG[w] > 0 && ammo[w] < WMAG[w] && reloadTimer == 0) reloadTimer = WREL[w];
    }

    double rayWall(double dx, double dy, double range) {
        for (double t = 0.05; t < range; t += 0.05)
            if (MAP[(int) (py + dy * t)][(int) (px + dx * t)] != 0) return t;
        return range;
    }

    // hit zones: 0 head, 1 torso, 2 left arm, 3 right arm, 4 left leg, 5 right leg, -1 miss.
    // lat = sideways offset from enemy centre, z = height of the bullet (0 floor .. 0.92 top of head)
    int zone(Enemy e, double lat, double z) {
        if (e.dead || z < 0) return -1;
        if (e.legLGone && e.legRGone) z += 0.4;           // crawling: body is lower
        double al = Math.abs(lat);
        if (z > 0.92 || al > 0.30) return -1;
        if (z >= 0.75) return (!e.headGone && al < 0.10) ? 0 : -1;
        if (z >= 0.40) {
            if (al < 0.20) return 1;
            return lat < 0 ? (e.armLGone ? -1 : 2) : (e.armRGone ? -1 : 3);
        }
        if (al >= 0.15) return -1;
        return lat < 0 ? (e.legLGone ? -1 : 4) : (e.legRGone ? -1 : 5);
    }

    void fire(int w) {
        noise(px, py, WNOISE[w]);
        double slope = (shear + kick) / H;                 // vertical aim: height gained per unit distance
        for (int i = 0; i < WPEL[w]; i++) {
            double off = (rnd.nextDouble() - 0.5) * WSPR[w];
            double a = pa + off, dx = Math.cos(a), dy = Math.sin(a);
            double vs = (rnd.nextDouble() - 0.5) * WSPR[w];
            double sl = (slope + vs) * Math.cos(off);
            double wall = rayWall(dx, dy, WRNG[w]);
            if (w == 8) {                                  // grenade flies in an arc and lands on the floor
                double aa = 0.5 * G / (WV[8] * WV[8]);
                double tl = (sl + Math.sqrt(sl * sl + 2 * aa)) / (2 * aa);
                wall = Math.min(wall, tl);
            }
            Enemy best = null; double bestT = wall; int bestZ = -1;
            for (int k = 0; k < enemies.size(); k++) {
                Enemy e = enemies.get(k);
                if (e.dead) continue;
                double ex = e.x - px, ey = e.y - py;
                double along = ex * dx + ey * dy;
                if (along < 0.2 || along > bestT) continue;
                double lat = -ex * dy + ey * dx;
                if (Math.abs(lat) > 0.32) continue;
                double z = 0.5 + sl * along - (WV[w] > 0 ? 0.5 * G * (along / WV[w]) * (along / WV[w]) : 0);
                int zn = zone(e, lat, z);
                if (zn < 0) continue;
                if (w == 7) hitZone(e, w, zn, along);      // sniper bullet goes through everyone in line
                else { best = e; bestT = along; bestZ = zn; }
            }
            if (w == 8) explode(px + dx * (bestT - 0.1), py + dy * (bestT - 0.1));
            else if (best != null) hitZone(best, w, bestZ, bestT);
        }
        kick = Math.min(60, kick + WREC[w]);
    }

    void wake(Enemy e) { e.state = 2; e.tx = px; e.ty = py; e.lx = px; e.ly = py; }

    void hitZone(Enemy e, int w, int zn, double along) {
        applyZone(e, WDMG[w] * Math.exp(-2 * WK[w] * along), zn);   // energy left after air drag
    }

    void applyZone(Enemy e, double D, int zn) {
        if (e.dead) return;
        double sz;
        switch (zn) {
            case 0:
                sz = 0.83; hitTxt = "HEADSHOT";
                e.hp -= D * 4; e.head -= D * 4;
                if (e.head <= 0) severHead(e);
                break;
            case 1:
                sz = 0.58; hitTxt = "TORSO";
                e.hp -= D; e.bleed += D * 0.006;
                break;
            case 2: case 3:
                sz = 0.58; hitTxt = "ARM";
                e.hp -= D * 0.25; e.bleed += D * 0.003;
                if (zn == 2) e.armL -= D; else e.armR -= D;
                if ((zn == 2 ? e.armL : e.armR) <= 0 || D >= 60) sever(e, zn);
                break;
            default:
                sz = 0.2; hitTxt = "LEG";
                e.hp -= D * 0.25; e.bleed += D * 0.003;
                if (zn == 4) e.legL -= D; else e.legR -= D;
                if ((zn == 4 ? e.legL : e.legR) <= 0 || D >= 60) sever(e, zn);
        }
        hitTimer = 40;
        e.stun = Math.max(e.stun, (int) (D / 6));
        wake(e);
        spray(e.x, e.y, sz, Math.min(60, 8 + (int) D / 3), 0.06);
        if (e.hp <= 0 || e.headGone || e.blood <= 0) kill(e, e.hp < -40);
    }

    void severHead(Enemy e) {
        if (e.headGone) return;
        e.headGone = true;
        int k = addPart(e.x, e.y, 0.83, (rnd.nextDouble() - 0.5) * 0.12, (rnd.nextDouble() - 0.5) * 0.12, 0.12, 0.09, SKIN);
        PF[k] = 2;
        spray(e.x, e.y, 0.8, 70, 0.1);
    }

    void sever(Enemy e, int zn) {
        boolean already = zn == 2 ? e.armLGone : zn == 3 ? e.armRGone : zn == 4 ? e.legLGone : e.legRGone;
        if (already) return;
        if (zn == 2) e.armLGone = true; else if (zn == 3) e.armRGone = true;
        else if (zn == 4) e.legLGone = true; else e.legRGone = true;
        e.stumps++; e.stun += 15; hitTxt = "SEVERED";
        int k = addPart(e.x, e.y, zn >= 4 ? 0.2 : 0.58, (rnd.nextDouble() - 0.5) * 0.14, (rnd.nextDouble() - 0.5) * 0.14,
                        0.1, 0.06, zn >= 4 ? rgb(50, 60, 110) : rgb(80, 115, 70));
        PF[k] = 2;
        spray(e.x, e.y, zn >= 4 ? 0.2 : 0.58, 40, 0.1);
    }

    void kill(Enemy e, boolean gib) {
        if (e.dead) return;
        if (e == grabber) grabber = null;
        if (e == heldEnemy) heldEnemy = null;
        e.dead = true; e.gibbed = gib; kills++;
        if (gib) {
            spray(e.x, e.y, 0.5, 300, 0.15);
            for (int i = 0; i < 14; i++) {
                double a = rnd.nextDouble() * Math.PI * 2, s = rnd.nextDouble() * 0.1;
                int col = rnd.nextInt(4) == 0 ? rgb(225, 215, 190) : rgb(110 + rnd.nextInt(40), 15, 20);
                int k = addPart(e.x, e.y, 0.5, Math.cos(a) * s, Math.sin(a) * s, rnd.nextDouble() * 0.12,
                                0.04 + rnd.nextDouble() * 0.05, col);
                PF[k] = 2;
            }
        } else {
            spray(e.x, e.y, 0.15, 90, 0.035);              // blood pool under the body
        }
    }

    void explode(double x, double y) {
        for (int i = 0; i < enemies.size(); i++) {
            Enemy e = enemies.get(i);
            if (e.dead) continue;
            double d = Math.hypot(e.x - x, e.y - y);
            if (d < 3) {
                double D = WDMG[8] * (1 - d / 3);
                e.hp -= D; e.stun = 25; wake(e);
                spray(e.x, e.y, 0.5, 25, 0.08);
                if (D > 40) sever(e, 2 + rnd.nextInt(4));
                if (D > 80) sever(e, 2 + rnd.nextInt(4));
                if (e.hp <= 0) kill(e, D > 70);
            }
        }
        double d = Math.hypot(px - x, py - y);
        if (d < 2.5) { hp -= (int) (35 * (1 - d / 2.5)); hurt = 12; bleedP += 0.01; }
        for (int i = 0; i < 60; i++) {                    // soot
            double a = rnd.nextDouble() * Math.PI * 2, s = rnd.nextDouble() * 0.12;
            addPart(x, y, 0.3, Math.cos(a) * s, Math.sin(a) * s, rnd.nextDouble() * 0.12,
                    0.02 + rnd.nextDouble() * 0.02, rgb(35, 30, 28));
        }
        flash = 8;
    }

    // ---------- particle pool ----------
    int addPart(double x, double y, double z, double vx, double vy, double vz, double size, int col) {
        int i = pHead;
        pHead = (pHead + 1) % MAXP;
        if (pN < MAXP) pN++;
        PX[i] = x; PY[i] = y; PZ[i] = z; VX[i] = vx; VY[i] = vy; VZ[i] = vz;
        PS[i] = size; PC[i] = col; PF[i] = 0;
        return i;
    }

    void spray(double x, double y, double z, int n, double speed) {
        for (int i = 0; i < n; i++) {
            double a = rnd.nextDouble() * Math.PI * 2, s = rnd.nextDouble() * speed;
            addPart(x, y, z + rnd.nextDouble() * 0.3 - 0.15, Math.cos(a) * s, Math.sin(a) * s,
                    rnd.nextDouble() * speed * 1.3, 0.015 + rnd.nextDouble() * 0.025,
                    rgb(120 + rnd.nextInt(100), rnd.nextInt(20), rnd.nextInt(20)));
        }
    }

    void updateParts() {
        for (int i = 0; i < pN; i++) {
            byte f = PF[i];
            if ((f & 1) != 0) continue;
            double nx = PX[i] + VX[i], ny = PY[i] + VY[i];
            if (MAP[(int) PY[i]][(int) nx] != 0) VX[i] *= -0.3; else PX[i] = nx;
            if (MAP[(int) ny][(int) PX[i]] != 0) VY[i] *= -0.3; else PY[i] = ny;
            PZ[i] += VZ[i]; VZ[i] -= 0.008;
            if (PZ[i] <= 0) {
                PZ[i] = 0;
                if (PIT[(int) PY[i]][(int) PX[i]]) { PF[i] = 1; PS[i] = 0; PC[i] = PITC; continue; }
                if ((f & 2) != 0 && Math.abs(VZ[i]) > 0.02) { VZ[i] *= -0.35; VX[i] *= 0.6; VY[i] *= 0.6; }
                else { PF[i] = (byte) (f | 1); if ((f & 2) == 0) PS[i] *= 1.8; }
            }
        }
    }

    // ---------- enemy AI ----------
    boolean hasLOS(double x0, double y0, double x1, double y1) {
        double d = Math.hypot(x1 - x0, y1 - y0);
        int n = (int) (d / 0.1) + 1;
        for (int i = 1; i < n; i++) {
            double t = (double) i / n;
            if (MAP[(int) (y0 + (y1 - y0) * t)][(int) (x0 + (x1 - x0) * t)] != 0) return false;
        }
        return true;
    }

    void noise(double nx, double ny, double radius) {
        for (int i = 0; i < enemies.size(); i++) {
            Enemy e = enemies.get(i);
            if (e.dead || e.state == 2) continue;
            double d = Math.hypot(e.x - nx, e.y - ny);
            if (d > radius) continue;                       // cheap early out
            if (!hasLOS(e.x, e.y, nx, ny)) d *= 1.5;       // walls muffle sound
            if (d < radius) { e.state = 1; e.tx = nx; e.ty = ny; e.lx = nx; e.ly = ny; }
        }
    }

    void startSearch(Enemy e) { e.state = 3; e.probes = 5; e.lx = e.tx; e.ly = e.ty; pickProbe(e); }

    void pickProbe(Enemy e) {
        for (int i = 0; i < 12; i++) {
            double x = e.lx + rnd.nextDouble() * 5 - 2.5, y = e.ly + rnd.nextDouble() * 5 - 2.5;
            int cx = (int) x, cy = (int) y;
            if (cx >= 1 && cy >= 1 && cx <= 14 && cy <= 14 && MAP[cy][cx] == 0 && !PIT[cy][cx]) { e.tx = x; e.ty = y; return; }
        }
        e.tx = e.lx; e.ty = e.ly;
    }

    void moveTo(Enemy e, double tx, double ty, double sp) {
        sp *= (e.legLGone && e.legRGone) ? 0.25 : (e.legLGone || e.legRGone) ? 0.6 : 1.0;   // limping / crawling
        double gx = tx, gy = ty;
        if (!pathClear(e.x, e.y, tx, ty)) {
            // path is cached for 8 frames instead of running BFS every frame
            if (--e.wt <= 0 || Math.hypot(e.wx - e.x, e.wy - e.y) < 0.15) {
                e.wt = 8;
                if (nextStep(e.x, e.y, tx, ty)) { e.wx = nsx; e.wy = nsy; } else { e.wx = tx; e.wy = ty; }
            }
            gx = e.wx; gy = e.wy;
        } else e.wt = 0;
        double d = Math.hypot(gx - e.x, gy - e.y);
        if (d < 1e-6) return;
        double nx = e.x + (gx - e.x) / d * sp, ny = e.y + (gy - e.y) / d * sp;
        if (MAP[(int) e.y][(int) nx] == 0 && !PIT[(int) e.y][(int) nx]) e.x = nx;
        if (MAP[(int) ny][(int) e.x] == 0 && !PIT[(int) ny][(int) e.x]) e.y = ny;
    }

    static final int[] DX4 = {1, -1, 0, 0}, DY4 = {0, 0, 1, -1};

    boolean nextStep(double ex, double ey, double tx, double ty) {
        int sx = (int) tx, sy = (int) ty, cx = (int) ex, cy = (int) ey;
        if (sx == cx && sy == cy) { nsx = tx; nsy = ty; return true; }
        if (MAP[sy][sx] != 0 || PIT[sy][sx]) return false;
        Arrays.fill(bdist, -1);
        int qh = 0, qt = 0, start = sy * 16 + sx, goal = cy * 16 + cx;
        bdist[start] = 0; bq[qt++] = start;
        while (qh < qt && bdist[goal] < 0) {
            int c = bq[qh++], x = c & 15, y = c >> 4;
            for (int k = 0; k < 4; k++) {
                int nx = x + DX4[k], ny = y + DY4[k];
                if (nx < 0 || ny < 0 || nx > 15 || ny > 15 || MAP[ny][nx] != 0 || PIT[ny][nx]) continue;
                int ni = ny * 16 + nx;
                if (bdist[ni] >= 0) continue;
                bdist[ni] = bdist[c] + 1; bq[qt++] = ni;
            }
        }
        if (bdist[goal] < 0) return false;
        int bx = cx, by = cy, bd = bdist[goal];
        for (int k = 0; k < 4; k++) {
            int nx = cx + DX4[k], ny = cy + DY4[k];
            if (nx < 0 || ny < 0 || nx > 15 || ny > 15) continue;
            int v = bdist[ny * 16 + nx];
            if (v >= 0 && v < bd) { bd = v; bx = nx; by = ny; }
        }
        nsx = bx + 0.5; nsy = by + 0.5;
        return true;
    }

    // ---------- software renderer (writes straight into an int[] pixel buffer) ----------
    void rectZ(int x0, int y0, int x1, int y1, int col, double depth) {
        if (x0 < 0) x0 = 0;
        if (y0 < 0) y0 = 0;
        if (x1 > W) x1 = W;
        if (y1 > H) y1 = H;
        for (int x = x0; x < x1; x++) {
            if (zb[x] < depth) continue;
            for (int y = y0; y < y1; y++) pix[y * W + x] = col;
        }
    }

    void ovalZ(int cx, int cy, int rx, int ry, int col, double depth) {
        if (rx < 1) rx = 1;
        if (ry < 1) ry = 1;
        for (int y = Math.max(0, cy - ry); y <= Math.min(H - 1, cy + ry); y++) {
            double t = (double) (y - cy) / ry;
            int hw = (int) (rx * Math.sqrt(Math.max(0, 1 - t * t)));
            for (int x = Math.max(0, cx - hw); x <= Math.min(W - 1, cx + hw); x++)
                if (zb[x] >= depth) pix[y * W + x] = col;
        }
    }

    void render() {
        double dx = Math.cos(pa), dy = Math.sin(pa), plx = -dy * 0.66, ply = dx * 0.66;
        int hz = H / 2 + (int) Math.max(-100, Math.min(100, shear + kick));   // horizon (vertical look)
        for (int y = 0; y < H; y++) {
            int c;
            if (y < hz) c = CEIL;
            else { int f = Math.min(60, (y - hz) * 60 / (H / 2)); c = rgb(25 + f, 22 + f * 3 / 4, 20 + f / 2); }
            Arrays.fill(pix, y * W, y * W + W, c);
        }

        for (int x = 0; x < W; x++) {
            double cam = 2.0 * x / W - 1, rx = dx + plx * cam, ry = dy + ply * cam;
            int mx = (int) px, my = (int) py, side = 0, hit = 0, stx, sty;
            double ddx = Math.abs(1 / rx), ddy = Math.abs(1 / ry), sdx, sdy;
            if (rx < 0) { stx = -1; sdx = (px - mx) * ddx; } else { stx = 1; sdx = (mx + 1 - px) * ddx; }
            if (ry < 0) { sty = -1; sdy = (py - my) * ddy; } else { sty = 1; sdy = (my + 1 - py) * ddy; }
            boolean lastPit = false;
            while (hit == 0) {
                if (sdx < sdy) { sdx += ddx; mx += stx; side = 0; } else { sdy += ddy; my += sty; side = 1; }
                hit = MAP[my][mx];
                boolean isPit = hit == 0 && PIT[my][mx];
                if (isPit) {                                   // paint the hole in the floor
                    double d1 = side == 0 ? sdx - ddx : sdy - ddy, d2 = Math.min(sdx, sdy);
                    int ya = hz + (int) (0.5 * H / Math.max(d1, 0.05)), yb = hz + (int) (0.5 * H / d2);
                    int a = Math.max(0, yb), b = Math.min(H - 1, ya);
                    for (int y = a; y <= b; y++) pix[y * W + x] = (!lastPit && y >= ya - 1) ? LIP : PITC;
                }
                lastPit = isPit;
            }
            double dist = side == 0 ? sdx - ddx : sdy - ddy;
            zb[x] = dist;
            int lh = (int) (H / dist), y0 = hz - lh / 2;
            int r = hit == 1 ? 120 : hit == 2 ? 130 : 70;
            int g = hit == 1 ? 120 : hit == 2 ? 80 : 110;
            int b = hit == 1 ? 130 : hit == 2 ? 60 : 90;
            double sh = Math.max(0.25, 1.0 - dist / 12) * (side == 1 ? 0.7 : 1);
            int col = rgb((int) (r * sh), (int) (g * sh), (int) (b * sh));
            int ys = Math.max(0, y0), ye = Math.min(H - 1, y0 + lh);
            for (int y = ys; y <= ye; y++) pix[y * W + x] = col;
        }

        double inv = 1.0 / (plx * dy - dx * ply);

        // enemies and corpses, sorted far -> near (insertion sort on a tiny array)
        int n = 0;
        for (int i = 0; i < enemies.size() && n < MAXE; i++) {
            Enemy e = enemies.get(i);
            if (e.gibbed) continue;
            double d = (e.x - px) * (e.x - px) + (e.y - py) * (e.y - py);
            int j = n++;
            while (j > 0 && ed[j - 1] < d) { ed[j] = ed[j - 1]; eo[j] = eo[j - 1]; j--; }
            ed[j] = d; eo[j] = i;
        }
        mkn = 0;
        final int pants = rgb(50, 60, 110), arm = rgb(80, 115, 70), red = rgb(150, 10, 10);
        for (int k = 0; k < n; k++) {
            Enemy e = enemies.get(eo[k]);
            double sx = e.x - px, sy = e.y - py;
            double tx = inv * (dy * sx - dx * sy), ty = inv * (-ply * sx + plx * sy);
            if (ty < 0.2) continue;
            int scx = (int) (W / 2 * (1 + tx / ty)), h = (int) (H / ty);
            if (scx < -h || scx > W + h) continue;
            int fy = hz + h / 2;
            int hurtR = (int) ((100 - Math.max(0, Math.min(100, e.hp))) * 0.8);
            int torso = rgb(90 + hurtR, 130 - hurtR, 80 - hurtR / 2);
            if (e.dead) {                                   // corpse lying on the floor
                rectZ(scx - (int) (0.2 * h), fy - (int) (0.1 * h), scx + (int) (0.2 * h), fy, torso, ty);
                if (!(e.legLGone && e.legRGone)) rectZ(scx + (int) (0.2 * h), fy - (int) (0.09 * h), scx + (int) (0.5 * h), fy, pants, ty);
                if (!e.headGone) ovalZ(scx - (int) (0.3 * h), fy - (int) (0.05 * h), (int) (0.1 * h), (int) (0.05 * h), SKIN, ty);
                continue;
            }
            if (e.legLGone && e.legRGone) fy += (int) (0.4 * h);         // crawling
            int h15 = (int) (0.15 * h), h01 = (int) (0.01 * h), h20 = (int) (0.2 * h);
            int h21 = (int) (0.21 * h), h30 = (int) (0.30 * h);
            int yL = fy - (int) (0.4 * h), yT = fy - (int) (0.75 * h), yA = fy - (int) (0.42 * h);
            if (!e.legLGone) rectZ(scx - h15, yL, scx - h01, fy, pants, ty);
            else rectZ(scx - h15, yL, scx - h01, yL + (int) (0.06 * h), red, ty);
            if (!e.legRGone) rectZ(scx + h01, yL, scx + h15, fy, pants, ty);
            else rectZ(scx + h01, yL, scx + h15, yL + (int) (0.06 * h), red, ty);
            if (!(e.legLGone && e.legRGone)) { /* legs drawn above */ }
            rectZ(scx - h20, yT, scx + h20, yL, torso, ty);
            if (!e.armLGone) rectZ(scx - h30, yT, scx - h21, yA, arm, ty);
            else rectZ(scx - h30, yT, scx - h21, yT + (int) (0.06 * h), red, ty);
            if (!e.armRGone) rectZ(scx + h21, yT, scx + h30, yA, arm, ty);
            else rectZ(scx + h21, yT, scx + h30, yT + (int) (0.06 * h), red, ty);
            if (!e.headGone) {
                ovalZ(scx, fy - (int) (0.835 * h), (int) (0.1 * h), (int) (0.085 * h), SKIN, ty);
                rectZ(scx - (int) (0.04 * h), fy - (int) (0.85 * h), scx - (int) (0.04 * h) + Math.max(1, (int) (0.03 * h)),
                      fy - (int) (0.85 * h) + Math.max(1, (int) (0.03 * h)), rgb(255, 0, 0), ty);
            } else rectZ(scx - (int) (0.04 * h), yT - (int) (0.05 * h), scx + (int) (0.04 * h), yT, red, ty);
            if (e.state > 0 && scx >= 0 && scx < W && ty < zb[scx] && mkn < MAXE) {
                mkx[mkn] = scx - 3; mky[mkn] = fy - h * 0.97f; mks[mkn] = e.state; mkn++;
            }
        }

        // particles (blood, gibs, soot)
        for (int i = 0; i < pN; i++) {
            double sx = PX[i] - px, sy = PY[i] - py;
            double ty = inv * (-ply * sx + plx * sy);
            if (ty < 0.15) continue;
            double tx = inv * (dy * sx - dx * sy);
            int scx = (int) (W / 2 * (1 + tx / ty));
            if (scx < 0 || scx >= W || ty > zb[scx]) continue;
            int scy = (int) (hz + (0.5 - PZ[i]) * H / ty), s = Math.max(1, (int) (PS[i] * H / ty));
            byte f = PF[i];
            if (f == 1) ovalZ(scx, scy, s, Math.max(1, s / 3), PC[i], ty);
            else { int x0 = scx - s / 2, y0 = scy - s / 2; rectZ(x0, y0, x0 + s, y0 + s, PC[i], ty); }
        }

        bmp.setPixels(pix, 0, W, 0, 0, W, H);

        // overlays drawn with Canvas
        p.setStyle(Paint.Style.FILL);
        if (hurt > 0) { p.setColor(Color.argb(90, 200, 0, 0)); bc.drawRect(0, 0, W, H, p); }
        if (bleedP > 0.003) { p.setColor(Color.argb(Math.min(70, (int) (bleedP * 2000)), 150, 0, 0)); bc.drawRect(0, 0, W, H, p); }
        p.setTextSize(22);
        for (int i = 0; i < mkn; i++) {
            p.setColor(mks[i] == 2 ? Color.RED : Color.YELLOW);
            bc.drawText(mks[i] == 2 ? "!" : "?", mkx[i], mky[i], p);
        }
        if (fallState == 0) drawGun();
        if (fallState == 1) { p.setColor(Color.argb(Math.min(210, fallT * 6), 0, 0, 0)); bc.drawRect(0, 0, W, H, p); }
        else if (fallState >= 2) {                           // hanging on the edge by your hands
            p.setColor(Color.argb(80, 0, 0, 0)); bc.drawRect(0, 0, W, H, p);
            float up = fallState == 3 ? climbT / 45f * 70f : 0f;
            p.setColor(Color.rgb(80, 115, 70));
            bc.drawRect(W / 2f - 100, H - up, W / 2f - 70, H, p);
            bc.drawRect(W / 2f + 70, H - up, W / 2f + 100, H, p);
            p.setColor(SKIN);
            bc.drawRect(W / 2f - 110, H - 45 - up, W / 2f - 60, H - up, p);
            bc.drawRect(W / 2f + 60, H - 45 - up, W / 2f + 110, H - up, p);
        }
        if (kickAnim > 0) {                                 // kick animation: a boot swings up
            double pr = 1 - kickAnim / 10.0;
            float top = (float) (H - 30 - 130 * Math.sin(pr * Math.PI));
            p.setColor(Color.rgb(50, 60, 110)); bc.drawRect(W / 2f - 24, top, W / 2f + 24, H, p);
            p.setColor(Color.rgb(90, 60, 40)); bc.drawRect(W / 2f - 30, top, W / 2f + 30, top + 24, p);
        }
        p.setColor(Color.WHITE);
        bc.drawRect(W / 2f - 5, H / 2f, W / 2f + 5, H / 2f + 1, p);
        bc.drawRect(W / 2f, H / 2f - 5, W / 2f + 1, H / 2f + 5, p);
    }

    void drawGun() {
        int w = weapon, gw = GW[w], gh = GH[w], gl = GL[w];
        float rec = cooldown > WCD[w] - 4 ? 8 : 0;
        if (reloadTimer > 0) rec = 25;
        float cx = W / 2f;
        p.setColor(w == 0 ? Color.rgb(190, 190, 200) : Color.rgb(40, 40, 45));
        bc.drawRect(cx - gw / 2f, H - gh + rec, cx + gw / 2f, H + rec, p);
        if (gl > 0) {
            p.setColor(Color.rgb(75, 75, 80));
            bc.drawRect(cx - gw / 4f, H - gh - gl + rec, cx + gw / 4f, H - gh + rec, p);
        }
        if (flash > 0 && w != 0) {
            p.setColor(Color.rgb(255, 220, 100));
            bc.drawCircle(cx, H - gh - gl - 4 + rec, 8 + gw / 4f, p);
        }
    }

    void hud(Canvas c) {
        int w = c.getWidth(), h = c.getHeight();
        p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); p.setTextSize(h / 20f);
        c.drawText("HP " + Math.max(hp, 0) + "   Kills " + kills + "   Wave " + wave, 20, h / 14f, p);
        String ws = WN[weapon] + (WMAG[weapon] > 0 ? "   " + ammo[weapon] + "/" + WMAG[weapon] : "")
                    + (reloadTimer > 0 ? "   RELOADING" : "");
        c.drawText(ws, 20, h / 14f + h / 15f, p);

        p.setTextSize(h / 22f);
        float ly = h / 14f + h / 15f * 2;
        if (bleedP > 0.003) { p.setColor(Color.RED); c.drawText("BLEEDING", 20, ly, p); ly += h / 17f; }
        if (legInj > 0) { p.setColor(Color.rgb(255, 160, 0)); c.drawText("LEG INJURED - SLOW", 20, ly, p); ly += h / 17f; }
        if (armInj > 0) { p.setColor(Color.rgb(255, 160, 0)); c.drawText("ARM INJURED - SHAKY AIM", 20, ly, p); }
        if (armInj > 0) ly += h / 17f;
        if (grabber != null) { p.setColor(Color.RED); c.drawText("GRABBED! MASH KICK", 20, ly, p); }
        else if (heldEnemy != null) { p.setColor(Color.GREEN); c.drawText("HOLDING: KICK or GRAB = THROW", 20, ly, p); }
        String fs = fallState == 1 ? "FALLING! TAP GRAB!" : fallState == 2 ? "HANGING - TAP GRAB TO CLIMB" : fallState == 3 ? "CLIMBING..." : null;
        if (fs != null) { p.setColor(Color.RED); p.setTextSize(h / 14f); c.drawText(fs, (w - p.measureText(fs)) / 2, h / 2f + h / 8f, p); }
        if (banner > 0) { p.setColor(Color.WHITE); p.setTextSize(h / 9f); String mn = "MAP: " + MAP_NAMES[mapIdx]; c.drawText(mn, (w - p.measureText(mn)) / 2, h / 4f, p); }
        if (hitTimer > 0) {
            p.setColor("HEADSHOT".equals(hitTxt) || "SEVERED".equals(hitTxt) ? Color.RED : Color.YELLOW);
            p.setTextSize(h / 14f);
            c.drawText(hitTxt, (w - p.measureText(hitTxt)) / 2, h / 2f - h / 12f, p);
        }
        p.setColor(Color.argb(firing ? 140 : 80, 220, 30, 30));
        c.drawCircle(fireX(), fireY(), 100, p);
        p.setColor(Color.argb(80, 60, 120, 220));
        c.drawCircle(swapX(), swapY(), 70, p);
        c.drawCircle(relX(), relY(), 70, p);
        p.setColor(Color.argb(90, 220, 140, 30));
        c.drawCircle(kickX(), kickY(), 70, p);
        c.drawCircle(grabX(), grabY(), 70, p);
        p.setColor(Color.argb(210, 255, 255, 255)); p.setTextSize(h / 24f);
        c.drawText("FIRE", fireX() - p.measureText("FIRE") / 2, fireY() + h / 70f, p);
        c.drawText("SWAP", swapX() - p.measureText("SWAP") / 2, swapY() + h / 70f, p);
        c.drawText("RELOAD", relX() - p.measureText("RELOAD") / 2, relY() + h / 70f, p);
        c.drawText("KICK", kickX() - p.measureText("KICK") / 2, kickY() + h / 70f, p);
        c.drawText("GRAB", grabX() - p.measureText("GRAB") / 2, grabY() + h / 70f, p);

        if (movePid >= 0) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(Color.argb(150, 255, 255, 255));
            c.drawCircle(moveX0, moveY0, 100, p);
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(moveX0 + mvx * 100, moveY0 + mvy * 100, 40, p);
        }

        if (hp <= 0) {
            p.setColor(Color.RED); p.setTextSize(h / 8f);
            String t = "YOU DIED";
            c.drawText(t, (w - p.measureText(t)) / 2, h / 2f, p);
            p.setColor(Color.WHITE); p.setTextSize(h / 18f);
            String t2 = "tap to restart";
            c.drawText(t2, (w - p.measureText(t2)) / 2, h / 2f + h / 10f, p);
        }
    }
}
